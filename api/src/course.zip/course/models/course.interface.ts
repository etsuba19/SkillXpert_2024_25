export interface CourseI {
    id: number;
    title: string,
    difficulty: string,
    description: string,
    img_url: string,
    rating: number
}